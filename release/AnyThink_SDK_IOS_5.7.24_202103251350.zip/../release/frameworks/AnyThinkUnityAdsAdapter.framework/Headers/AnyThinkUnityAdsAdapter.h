//
//  AnyThinkUnityAdsAdapter.h
//  AnyThinkUnityAdsAdapter
//
//  Created by Topon on 11/16/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkUnityAdsAdapter.
FOUNDATION_EXPORT double AnyThinkUnityAdsAdapterVersionNumber;

//! Project version string for AnyThinkUnityAdsAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkUnityAdsAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkUnityAdsAdapter/PublicHeader.h>


