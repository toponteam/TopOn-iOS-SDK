//
//  AnyThinkAppnextAdapter.h
//  AnyThinkAppnextAdapter
//
//  Created by Topon on 11/16/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkAppnextAdapter.
FOUNDATION_EXPORT double AnyThinkAppnextAdapterVersionNumber;

//! Project version string for AnyThinkAppnextAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkAppnextAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkAppnextAdapter/PublicHeader.h>


