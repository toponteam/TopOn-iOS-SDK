//
//  AnyThinkSigmobAdapter.h
//  AnyThinkSigmobAdapter
//
//  Created by Topon on 11/15/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkSigmobAdapter.
FOUNDATION_EXPORT double AnyThinkSigmobAdapterVersionNumber;

//! Project version string for AnyThinkSigmobAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkSigmobAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkSigmobAdapter/PublicHeader.h>


