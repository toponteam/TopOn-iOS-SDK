//
//  AnyThinkOguryAdapter.h
//  AnyThinkOguryAdapter
//
//  Created by Topon on 11/16/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkOguryAdapter.
FOUNDATION_EXPORT double AnyThinkOguryAdapterVersionNumber;

//! Project version string for AnyThinkOguryAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkOguryAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkOguryAdapter/PublicHeader.h>


