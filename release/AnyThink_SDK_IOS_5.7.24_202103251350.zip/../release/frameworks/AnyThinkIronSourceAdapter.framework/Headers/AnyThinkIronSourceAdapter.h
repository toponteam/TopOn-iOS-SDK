//
//  AnyThinkIronSourceAdapter.h
//  AnyThinkIronSourceAdapter
//
//  Created by Topon on 11/16/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkIronSourceAdapter.
FOUNDATION_EXPORT double AnyThinkIronSourceAdapterVersionNumber;

//! Project version string for AnyThinkIronSourceAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkIronSourceAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkIronSourceAdapter/PublicHeader.h>


