//
//  AnyThinkFacebookAdapter.h
//  AnyThinkFacebookAdapter
//
//  Created by Topon on 11/14/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkFacebookAdapter.
FOUNDATION_EXPORT double AnyThinkFacebookAdapterVersionNumber;

//! Project version string for AnyThinkFacebookAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkFacebookAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkFacebookAdapter/PublicHeader.h>


