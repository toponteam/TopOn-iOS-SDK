//
//  AnyThinkMyTargetAdapter.h
//  AnyThinkMyTargetAdapter
//
//  Created by Topon on 12/29/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkMyTargetAdapter.
FOUNDATION_EXPORT double AnyThinkMyTargetAdapterVersionNumber;

//! Project version string for AnyThinkMyTargetAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkMyTargetAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkMyTargetAdapter/PublicHeader.h>


