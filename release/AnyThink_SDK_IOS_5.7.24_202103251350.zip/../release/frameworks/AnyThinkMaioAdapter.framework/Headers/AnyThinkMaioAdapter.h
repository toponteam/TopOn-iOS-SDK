//
//  AnyThinkMaioAdapter.h
//  AnyThinkMaioAdapter
//
//  Created by Topon on 11/16/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkMaioAdapter.
FOUNDATION_EXPORT double AnyThinkMaioAdapterVersionNumber;

//! Project version string for AnyThinkMaioAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkMaioAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkMaioAdapter/PublicHeader.h>


