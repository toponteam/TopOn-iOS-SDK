//
//  AnyThinkTapjoyAdapter.h
//  AnyThinkTapjoyAdapter
//
//  Created by Topon on 11/16/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkTapjoyAdapter.
FOUNDATION_EXPORT double AnyThinkTapjoyAdapterVersionNumber;

//! Project version string for AnyThinkTapjoyAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkTapjoyAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkTapjoyAdapter/PublicHeader.h>


