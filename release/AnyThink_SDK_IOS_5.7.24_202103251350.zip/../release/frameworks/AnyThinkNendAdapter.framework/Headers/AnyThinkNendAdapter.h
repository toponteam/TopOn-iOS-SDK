//
//  AnyThinkNendAdapter.h
//  AnyThinkNendAdapter
//
//  Created by Topon on 11/16/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkNendAdapter.
FOUNDATION_EXPORT double AnyThinkNendAdapterVersionNumber;

//! Project version string for AnyThinkNendAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkNendAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkNendAdapter/PublicHeader.h>


