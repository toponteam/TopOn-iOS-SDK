//
//  AnyThinkKidozAdapter.h
//  AnyThinkKidozAdapter
//
//  Created by Topon on 12/23/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkKidozAdapter.
FOUNDATION_EXPORT double AnyThinkKidozAdapterVersionNumber;

//! Project version string for AnyThinkKidozAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkKidozAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkKidozAdapter/PublicHeader.h>


