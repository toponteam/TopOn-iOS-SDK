//
//  AnyThinkAdColonyAdapter.h
//  AnyThinkAdColonyAdapter
//
//  Created by Topon on 11/16/20.
//  Copyright © 2020 AnyThink. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AnyThinkAdColonyAdapter.
FOUNDATION_EXPORT double AnyThinkAdColonyAdapterVersionNumber;

//! Project version string for AnyThinkAdColonyAdapter.
FOUNDATION_EXPORT const unsigned char AnyThinkAdColonyAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnyThinkAdColonyAdapter/PublicHeader.h>


